<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class IndexController extends AbstractController
{
   /* #[Route('/index', name: 'app_index')]
    public function index(): JsonResponse
    {
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/IndexController.php',
        ]);
    }*/
    public function save() {
        $entityManager = $this->getDoctrine()->getManager();
        $article = new Article();
        $article->setTitre('Article 1');
        $article->setContenu('Ariclee');
        $article->setDateDePublication(14/50/2022);
       
        $entityManager->persist($article);
        $entityManager->flush();
        return new Response('Article enregisté avec id '.$article->getId());
        }
        public function new(Request $request) {
            $article = new Article();
            $form = $this->createFormBuilder($article)
            ->add('nom', TextType::class)
            ->add('prix', TextType::class)
            ->add('save', SubmitType::class, array('label' => 'Créer'))->getForm();
           
           
            $form->handleRequest($request);
           
            if($form->isSubmitted() && $form->isValid()) {
            $article = $form->getData();
           
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($article);
            $entityManager->flush();
           
            return $this->redirectToRoute('article_list');
            }
            return $this->render('templates/add.html.twig',['form' => $form->createView()]);
            }
            public function show($id) {
                $article = $this->getDoctrine()->getRepository(Article::class)
                ->find($id);
                return $this->render('templates/show.html.twig',array('article' => $article));
                 }
public function edit(Request $request, $id) {
        $article = new Article();
        $article = $this->getDoctrine()->getRepository(Article::class)->find($id);
                   
        $form = $this->createFormBuilder($article)
      ->add('nom', TextType::class)
         ->add('prix', TextType::class)
        ->add('save', SubmitType::class, array('label' => 'Modifier'))->getForm();
                   
                    $form->handleRequest($request);
                    if($form->isSubmitted() && $form->isValid()) {
                   
                    $entityManager = $this->getDoctrine()->getManager();
                    $entityManager->flush();
                   
                    return $this->redirectToRoute('article_list');
                    }
                    return $this->render('templates/edit.html.twig', ['form' => $form->createView()]);
      
                }   
                public function delete(Request $request, $id) {
                    $article = $this->getDoctrine()->getRepository(Article::class)->find($id);
                   
                    $entityManager = $this->getDoctrine()->getManager();
                    $entityManager->remove($article);
                    $entityManager->flush();
                   
                    $response = new Response();
                    $response->send();
                    return $this->redirectToRoute('article_list');
                    }
                                                             
}
